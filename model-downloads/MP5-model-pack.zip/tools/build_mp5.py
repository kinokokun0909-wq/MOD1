import argparse, base64, io, json, math, pathlib, random, uuid
from PIL import Image, ImageDraw, ImageFont

parser=argparse.ArgumentParser()
parser.add_argument('--project',type=pathlib.Path,default=pathlib.Path('/workspace/MOD1'))
parser.add_argument('--output',type=pathlib.Path,default=pathlib.Path('/workspace/mp5-model'))
args=parser.parse_args(); ROOT=args.project; OUT=args.output
OUT.mkdir(parents=True,exist_ok=True)
PALETTE={
 'polymer':(33,38,42),'polymer_edge':(48,54,58),'steel':(36,43,48),
 'metal_edge':(70,80,87),'recess':(10,14,18),'rubber':(23,26,29),
 'magazine':(30,38,43),'silver':(103,114,121),'red':(173,48,40),
 'sight':(51,57,61),'grip':(30,35,39),'bolt':(75,84,90)
}
random.seed(5); atlas=Image.new('RGBA',(256,256),(0,0,0,0)); draw=ImageDraw.Draw(atlas)
UV={}
for i,(name,color) in enumerate(PALETTE.items()):
 x=i%4*64; y=i//4*64; UV[name]=[x/16,y/16,(x+64)/16,(y+64)/16]
 for yy in range(64):
  for xx in range(64):
   noise=random.choice([-2,-1,0,0,0,1,2])
   if name in ['steel','silver','metal_edge','bolt']:noise+=1 if yy%9==0 else 0
   if name=='grip' and (xx%4==0 and yy%4==0):noise+=6
   c=tuple(max(0,min(255,v+noise)) for v in color)
   atlas.putpixel((x+xx,y+yy),c+(255,))
 # Restrained painted edges remain visible with Minecraft's nearest filtering.
 edge=tuple(min(255,v+10) for v in color)+(255,)
 draw.line((x,y,x+63,y),fill=edge,width=1)
 draw.line((x,y,x,y+63),fill=edge,width=1)

font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
try:
 font=ImageFont.truetype(font_path,12); small=ImageFont.truetype(font_path,9)
except OSError:font=small=ImageFont.load_default()
draw.rectangle((0,200,127,231),fill=PALETTE['polymer']+(255,))
draw.text((8,202),'S       E       F',font=font,fill=(179,58,47,255))
for cx,count in [(17,0),(60,1),(104,3)]:
 draw.line((cx-4,225,cx+4,218),fill=(182,61,49,255),width=2)
 for n in range(count):draw.rectangle((cx-5+n*4,216,cx-4+n*4,218),fill=(185,66,51,255))
UV['selector']=[0,200/16,128/16,232/16]
draw.rectangle((128,200,255,231),fill=PALETTE['steel']+(255,))
draw.text((138,206),'MP5   9 x 19',font=small,fill=(116,128,137,255))
UV['engraving']=[128/16,200/16,256/16,232/16]
atlas.save(OUT/'mp5.png')

elements=[]; group='Receiver'
def cube(name,a,b,mat='steel',rotation=None,label=False):
 for j in range(3):assert -16<=a[j]<b[j]<=32,(name,a,b)
 element={'name':name,'from':[round(v,5) for v in a],
  'to':[round(v,5) for v in b],
  'faces':{face:{'uv':UV[mat],'texture':'#0'} for face in ['north','south','east','west','up','down']}}
 if rotation:
  axis,angle,origin=rotation
  assert axis in 'xyz' and angle in [-45,-22.5,0,22.5,45]
  element['rotation']={'axis':axis,'angle':angle,'origin':origin,'rescale':False}
 if label:
  element['faces']['north']['uv']=UV[label]
  element['faces']['south']['uv']=UV[label]
 element['_group']=group;elements.append(element)
def centered(name,c,size,mat='steel',axis=None,angle=0):
 a=[c[j]-size[j]/2 for j in range(3)];b=[c[j]+size[j]/2 for j in range(3)]
 cube(name,a,b,mat,(axis,angle,list(c)) if axis else None)
def cylinder_x(name,x0,x1,y,z,r,mat='steel'):
 c=[(x0+x1)/2,y,z]; d=x1-x0; q=r*.828427
 centered(name+' vertical',c,[d,2*r,q],mat)
 centered(name+' horizontal',c,[d,q,2*r],mat)
 for angle in [-45,45]:centered(name+' bevel',c,[d,2*r,q],mat,'x',angle)
def cylinder_y(name,x,y0,y1,z,r,mat='steel'):
 c=[x,(y0+y1)/2,z];d=y1-y0;q=r*.828427
 centered(name+' fore',c,[2*r,d,q],mat)
 centered(name+' side',c,[q,d,2*r],mat)
 for angle in [-45,45]:centered(name+' bevel',c,[2*r,d,q],mat,'y',angle)
def ring_x(name,x,y,z,r,t=.1,depth=.25,mat='sight'):
 q=r*.414214
 for s in [-1,1]:
  centered(name+' top/bottom',[x,y+s*r,z],[depth,t,2*q+t],mat)
  centered(name+' side',[x,y,z+s*r],[depth,2*q+t,t],mat)
 for sy in [-1,1]:
  for sz in [-1,1]:
   centered(name+' corner',[x,y+sy*(r+q)/2,z+sz*(r+q)/2],
    [depth,math.sqrt(2)*(r-q)+t,t],mat,'x',-sy*sz*45)

# Stamped receiver and the rounded roller-delayed action housing.
cube('Receiver steel shell',[6.7,11.35,6.95],[17.8,14.25,9.05])
cube('Receiver bottom seam',[7.05,11.17,6.88],[17.55,11.44,9.12],'metal_edge')
cube('Receiver side panel',[7.3,11.52,6.87],[17.15,13.5,6.99],'steel')
cube('Receiver side panel',[7.3,11.52,9.01],[17.15,13.5,9.13],'steel')
cylinder_x('Rounded receiver crown',6.8,17.75,14.08,8,.76)
cube('Receiver upper rib',[8.5,14.5,7.79],[15.9,14.69,8.21],'metal_edge')
cube('Top stamped seam',[8.65,14.35,7.34],[15.85,14.48,7.52],'recess')
cube('Top stamped seam',[8.65,14.35,8.48],[15.85,14.48,8.66],'recess')
cube('Ejection port recess',[11.55,12.25,9.13],[15.2,13.05,9.2],'recess')
cube('Bolt visible inside port',[11.73,12.42,9.2],[14.84,12.83,9.24],'bolt')
cube('Ejection port lip',[11.45,13.05,9.13],[15.3,13.16,9.26],'metal_edge')
cube('Model engraving',[9.6,13.31,6.82],[13.9,13.9,6.88],'steel',label='engraving')
for x in [7.1,17.05]:
 for z in [6.82,9.18]:centered('Receiver push pin',[x,11.78,z],[.28,.28,.12],'metal_edge')

group='Barrel and muzzle'
cylinder_x('Barrel',-6.9,.45,13.72,8,.26,'steel')
cylinder_x('Three lug mounting collar',-4.05,-3.75,13.72,8,.43,'metal_edge')
for y,z in [(14.16,8),(13.48,7.61),(13.48,8.39)]:
 centered('Muzzle mounting lug',[-3.88,y,z],[.42,.2,.2],'steel')
cylinder_x('Muzzle crown',-7.05,-6.68,13.72,8,.33,'metal_edge')
cylinder_x('Dark muzzle opening',-7.075,-7.055,13.72,8,.22,'recess')
cylinder_x('Front sight barrel band',-.6,-.12,13.72,8,.52,'steel')

group='Charging tube'
cylinder_x('Charging handle tube',-.08,7.35,14.42,8,.31,'steel')
cube('Charging tube guide rail',[.45,14.68,7.79],[6.48,14.82,8.21],'metal_edge')
cube('Charging handle slot',[.55,14.2,7.64],[5.9,14.55,7.73],'recess')
cube('Charging handle arm',[1.18,14.38,6.39],[1.51,14.62,7.81],'steel')
centered('Charging handle knob',[1.38,14.5,6.33],[.73,.39,.42],'polymer','y',22.5)
cylinder_x('Charging tube end cap',-.3,.02,14.42,8,.33,'metal_edge')

group='Polymer handguard'
cube('Wide forearm core',[-.15,11.06,6.76],[6.6,13.4,9.24],'polymer')
cube('Handguard bottom',[-.02,10.98,7.13],[6.82,11.28,8.87],'polymer_edge')
cube('Handguard receiver collar',[6.5,10.88,6.67],[7.1,13.61,9.33],'recess')
cube('Handguard retaining pin',[-.32,12.15,6.7],[.12,12.64,9.3],'metal_edge')
for side,z in [('left',6.72),('right',9.25)]:
 cube('Handguard '+side+' seam',[.55,11.54,z],[6.28,11.64,z+.04],'polymer_edge')
 cube('Handguard '+side+' upper seam',[.55,13.11,z],[6.23,13.19,z+.04],'recess')

group='Lower receiver and pistol grip'
cube('Trigger housing',[7.6,9.45,6.93],[16.9,11.42,9.07],'polymer')
cube('Trigger housing shoulder',[15.8,10.78,6.91],[17.45,11.55,9.09],'polymer_edge')
cube('Magazine well',[7.85,9.35,6.94],[10.26,10.95,9.06],'steel')
cube('Magazine well mouth',[7.7,9.3,6.87],[10.4,9.59,9.13],'metal_edge')
cube('Grip main',[15.36,4.6,7.04],[17.28,9.62,8.96],'grip',
 ('z',22.5,[16.32,9.2,8]))
cube('Grip heel',[15.25,4.4,6.99],[17.46,4.7,9.01],'polymer_edge',
 ('z',22.5,[16.32,9.2,8]))
for y in [5.1,5.55,6,6.45,6.9,7.35,7.8]:
 cube('Grip checkering',[15.3,y,7],[15.45,y+.095,9],'polymer_edge',
  ('z',22.5,[16.32,9.2,8]))
for z in [6.82,9.08]:
 cube('Selector markings',[11.1,9.84,z],[15.4,11.06,z+.055],'polymer',label='selector')
 centered('Selector pivot',[14.52,10.23,z-.035 if z<8 else z+.09],
  [.38,.38,.1],'metal_edge')
 centered('Selector lever',[14.12,10.13,z-.065 if z<8 else z+.12],
  [.79,.16,.09],'polymer_edge','z',22.5)
centered('Magazine release button',[10.06,10.24,9.17],[.38,.36,.16],'metal_edge')
cube('Paddle magazine release',[9.69,8.88,7.53],[10.19,9.44,8.47],'polymer_edge')

group='Trigger and guard'
cube('Trigger guard front',[10.48,7.31,7.37],[10.68,9.46,8.63],'polymer_edge')
cube('Trigger guard bottom',[10.84,6.92,7.37],[14.7,7.13,8.63],'polymer_edge')
centered('Trigger guard front bend',[10.72,7.16,8],[.22,.55,1.26],'polymer_edge','z',45)
centered('Trigger guard rear bend',[15.15,8.3,8],[.22,2.5,1.26],'polymer_edge','z',-22.5)
cube('Trigger upper',[12.42,8.16,7.87],[12.64,9.46,8.13],'steel')
centered('Trigger curve',[12.62,8.0,8],[.18,.59,.26],'metal_edge','z',-22.5)

group='Curved magazine'
x=9.03; y=9.66
for i,angle in enumerate([0,0,-22.5,-22.5,-22.5,-45]):
 length=1.45
 a=math.radians(angle);dx=math.sin(a)*length;dy=-math.cos(a)*length
 cx=x+dx/2;cy=y+dy/2
 centered('Magazine segment '+str(i+1),[cx,cy,8],[1.82,length+.08,1.72],
  'magazine','z',angle)
 for z in [7.12,8.88]:
  centered('Magazine pressed central rib',[cx+.25,cy,z],[.24,length+.11,.065],
   'polymer_edge','z',angle)
  centered('Magazine pressed groove',[cx-.32,cy,z],[.09,length+.11,.07],
   'recess','z',angle)
 if i in [2,5]:
  centered('Magazine curved joint',[x,y,8],[1.82,.5,1.72],'magazine','z',angle)
 x+=dx;y+=dy
centered('Magazine floor plate',[x,y-.05,8],[2.0,.24,1.9],'metal_edge','z',-45)

group='Retractable stock'
cube('Receiver rear plate',[17.7,11.38,6.71],[18.31,14.82,9.29],'polymer')
for z in [6.82,9.06]:
 cube('Stock rail',[18.15,13.49,z],[25.62,13.72,z+.13],'metal_edge')
 cube('Stock rail guide',[17.16,13.29,z-.08],[18.91,13.86,z+.22],'steel')
cylinder_x('Stock lock collar',18.03,18.38,13.3,8,1.09,'steel')
cube('Stock lock release',[18.05,11.1,7.4],[18.49,11.57,8.6],'metal_edge')
cube('Stock shoulder',[24.71,12.37,7.25],[26.12,14.48,8.75],'polymer')
cube('Stock butt',[25.54,9.82,7.23],[26.34,14.22,8.77],'rubber',
 ('z',22.5,[25.88,13.8,8]))
cube('Butt plate rim',[26.26,9.73,7.16],[26.47,14.31,8.84],'polymer_edge',
 ('z',22.5,[25.88,13.8,8]))
for y in [10.15,10.6,11.05,11.5,11.95,12.4,12.85,13.3]:
 cube('Rubber butt serration',[26.41,y,7.22],[26.5,y+.08,8.78],'recess',
  ('z',22.5,[25.88,13.8,8]))
cube('Rear sling eye top',[25.1,10.29,7.53],[25.7,10.43,8.47],'metal_edge',('z',22.5,[25.88,13.8,8]))
cube('Rear sling eye bottom',[25.1,9.79,7.53],[25.7,9.93,8.47],'metal_edge',('z',22.5,[25.88,13.8,8]))
for z in [7.53,8.33]:cube('Rear sling eye side',[25.1,9.93,z],[25.7,10.29,z+.14],'metal_edge',('z',22.5,[25.88,13.8,8]))

group='Iron sights'
cube('Front sight foot',[-.75,14.12,7.55],[-.05,15.64,8.45],'sight')
ring_x('Front hood',-.4,16.05,8,.64,.095,.32)
cube('Front sight post',[-.48,15.5,7.945],[-.32,16.15,8.055],'metal_edge')
cube('Rear sight base',[15.38,14.6,7.36],[16.93,14.92,8.64],'metal_edge')
cylinder_y('Rear rotary diopter',16.15,14.91,15.7,8,.57,'sight')
centered('Rear drum rim',[16.15,15.73,8],[1.12,.12,1.12],'metal_edge','y',22.5)
cube('Rear aperture recess',[15.63,15.09,7.82],[15.7,15.52,8.18],'recess')
cube('Rear aperture', [15.58,15.24,7.92],[15.63,15.39,8.08],'recess')

display={
 'thirdperson_righthand':{'rotation':[0,-90,-5],'translation':[0,2,-1],'scale':[.45,.45,.45]},
 'thirdperson_lefthand':{'rotation':[0,90,5],'translation':[0,2,-1],'scale':[.45,.45,.45]},
 'firstperson_righthand':{'rotation':[0,-90,0],'translation':[1,-1,1],'scale':[.55,.55,.55]},
 'firstperson_lefthand':{'rotation':[0,90,0],'translation':[1,-1,1],'scale':[.55,.55,.55]},
 'gui':{'rotation':[10,-25,-12],'translation':[0,0,0],'scale':[.47,.47,.47]},
 'ground':{'rotation':[0,0,0],'translation':[0,2,0],'scale':[.3,.3,.3]},
 'fixed':{'rotation':[0,0,0],'translation':[0,0,0],'scale':[.48,.48,.48]},
 'head':{'rotation':[0,0,0],'translation':[0,8,0],'scale':[.45,.45,.45]}}
vanilla={'credit':'Original MP5-style model for MOD1','textures':{'0':'mod1:item/mp5','particle':'mod1:item/mp5'},
 'gui_light':'front','display':display,'elements':[{k:v for k,v in e.items() if not k.startswith('_') and k!='name'} for e in elements]}
(OUT/'mp5.json').write_text(json.dumps(vanilla,indent=2))
(OUT/'mp5.build.json').write_text(json.dumps({'elements':elements,'palette':PALETTE,'uv':UV,'display':display},indent=2))
for rel,source in [('models/item/mp5.json','mp5.json'),('textures/item/mp5.png','mp5.png')]:
 p=ROOT/'src/main/resources/assets/mod1'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes((OUT/source).read_bytes())
for lang,label in [('ja_jp','MP5'),('en_us','MP5')]:
 p=ROOT/'src/main/resources/assets/mod1/lang'/f'{lang}.json'
 existing=json.loads(p.read_text()) if p.exists() else {}
 existing['item.mod1.mp5']=label;p.write_text(json.dumps(existing,ensure_ascii=False,indent=2))

bb_elements=[];groups={}
for i,e in enumerate(elements):
 uid=str(uuid.uuid5(uuid.NAMESPACE_URL,f'mod1/mp5/{i}'))
 rotation=e.get('rotation',{});axis=rotation.get('axis');angles=[0,0,0]
 if axis:angles['xyz'.index(axis)]=rotation['angle']
 f={name:{'uv':face['uv'],'texture':0} for name,face in e['faces'].items()}
 bb_elements.append({'name':e['name'],'uuid':uid,'type':'cube','from':e['from'],'to':e['to'],
  'origin':rotation.get('origin',[sum(t)/2 for t in zip(e['from'],e['to'])]),
  'rotation':angles,'rescale':False,'box_uv':False,'autouv':0,'faces':f,'color':i%8})
 groups.setdefault(e['_group'],[]).append(uid)
project={'meta':{'format_version':'4.10','model_format':'java_block','box_uv':False},
 'name':'MP5 — retractable stock','model_identifier':'mp5','resolution':{'width':256,'height':256},
 'elements':bb_elements,'outliner':[{'name':g,'uuid':str(uuid.uuid5(uuid.NAMESPACE_URL,'mp5/'+g)),
  'origin':[8,8,8],'children':ids,'isOpen':False,'export':True} for g,ids in groups.items()],
 'display':display,'textures':[{'name':'mp5.png','id':'0','uuid':str(uuid.uuid4()),
  'source':'data:image/png;base64,'+base64.b64encode((OUT/'mp5.png').read_bytes()).decode(),
  'width':256,'height':256,'uv_width':256,'uv_height':256,'mode':'bitmap','saved':False,
  'namespace':'mod1','folder':'item','particle':True}]}
(OUT/'MP5.bbmodel').write_text(json.dumps(project,separators=(',',':')))
print('MP5:',len(elements),'cubes,',len(groups),'groups; Java item JSON and embedded-texture Blockbench project exported.')
