import bpy, json, math, pathlib, argparse, sys
from mathutils import Matrix, Vector

parser=argparse.ArgumentParser()
parser.add_argument('--output',type=pathlib.Path,default=pathlib.Path('/workspace/mp5-model'))
args=parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
OUT=args.output
model=json.loads((OUT/'mp5.build.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
texture=bpy.data.images.load(str(OUT/'mp5.png'));texture.pack()
materials={}
for kind,metal,rough in [('steel',.65,.37),('polymer',.05,.58)]:
 mat=bpy.data.materials.new('MP5 '+kind);mat.use_nodes=True
 nodes=mat.node_tree.nodes;bsdf=nodes.get('Principled BSDF')
 tex=nodes.new('ShaderNodeTexImage');tex.image=texture;tex.interpolation='Closest'
 mat.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Base Color'])
 bsdf.inputs['Metallic'].default_value=metal;bsdf.inputs['Roughness'].default_value=rough
 materials[kind]=mat

corners=[(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),
 (-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]
faces={'north':(3,2,1,0),'south':(4,5,6,7),'down':(0,1,5,4),
 'east':(1,2,6,5),'up':(2,3,7,6),'west':(3,0,4,7)}
collection=bpy.data.collections.new('MP5 / exportable model');bpy.context.scene.collection.children.link(collection)
objects=[];bounds=[]
for e in model['elements']:
 center=Vector([(a+b)/2 for a,b in zip(e['from'],e['to'])])
 half=Vector([(b-a)/2 for a,b in zip(e['from'],e['to'])])
 r=e.get('rotation');verts=[]
 for c in corners:
  v=center+Vector([c[j]*half[j] for j in range(3)])
  if r:
   origin=Vector(r['origin']);v=origin+Matrix.Rotation(math.radians(r['angle']),3,r['axis'].upper()) @ (v-origin)
  bounds.append(list(v));verts.append((v.x,-v.z,v.y))
 mesh=bpy.data.meshes.new(e['name']);mesh.from_pydata(verts,[],list(faces.values()));mesh.update()
 obj=bpy.data.objects.new(e['name'],mesh);collection.objects.link(obj)
 layer=mesh.uv_layers.new(name='Minecraft atlas')
 for poly,side in zip(mesh.polygons,faces):
  u0,v0,u1,v1=e['faces'][side]['uv']
  uv=[(u0/16,1-v1/16),(u1/16,1-v1/16),(u1/16,1-v0/16),(u0/16,1-v0/16)]
  for index,pair in zip(poly.loop_indices,uv):layer.data[index].uv=pair
 group=e['_group']
 polymer=group in ['Polymer handguard','Lower receiver and pistol grip','Retractable stock']
 obj.data.materials.append(materials['polymer' if polymer else 'steel'])
 objects.append(obj)

lo=[min(v[j] for v in bounds) for j in range(3)]
hi=[max(v[j] for v in bounds) for j in range(3)]
(OUT/'bounds.json').write_text(json.dumps(dict(min=lo,max=hi,dimensions=[hi[j]-lo[j] for j in range(3)]),indent=2))
bpy.ops.object.select_all(action='DESELECT')
for obj in objects:obj.select_set(True)
bpy.context.view_layer.objects.active=objects[0]
bpy.ops.export_scene.gltf(filepath=str(OUT/'MP5.glb'),export_format='GLB',use_selection=True)

scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=80
scene.cycles.use_denoising=False;scene.render.threads_mode='FIXED';scene.render.threads=5
scene.render.resolution_x=1800;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.world.use_nodes=True
background=scene.world.node_tree.nodes['Background'];background.inputs[0].default_value=(.12,.17,.23,1)
background.inputs[1].default_value=.7;scene.view_settings.view_transform='AgX'

bpy.ops.mesh.primitive_plane_add(size=1000,location=(8,-8,-.1))
floor=bpy.context.object;floor.name='Studio / not part of item'
mat=bpy.data.materials.new('Studio slate');mat.use_nodes=True
bsdf=mat.node_tree.nodes.get('Principled BSDF');bsdf.inputs['Base Color'].default_value=(.026,.035,.044,1)
bsdf.inputs['Roughness'].default_value=.7;floor.data.materials.append(mat)
def light(name,position,power,color,size):
 data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color
 obj=bpy.data.objects.new(name,data);scene.collection.objects.link(obj);obj.location=position
 obj.rotation_euler=(Vector((8,-8,9))-obj.location).to_track_quat('-Z','Y').to_euler()
light('Large key',(-12,-25,45),16000,(.9,.95,1),30)
light('Receiver highlight',(20,4,32),18000,(.7,.82,1),25)
light('Side fill',(15,-35,14),6500,(1,.86,.7),24)
cam_data=bpy.data.cameras.new('MP5 camera');cam=bpy.data.objects.new('MP5 camera',cam_data)
scene.collection.objects.link(cam);scene.camera=cam;cam_data.type='ORTHO';cam_data.ortho_scale=40;cam_data.clip_end=2000
def camera(location,target):
 cam.location=location;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
camera((-1,-66,28),(9,-8,9))
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'MP5.blend'))
scene.render.filepath=str(OUT/'preview-mp5.png');bpy.ops.render.render(write_still=True)
camera((9,-65,9),(9,-8,9));cam_data.ortho_scale=39
scene.render.filepath=str(OUT/'preview-mp5-profile.png');bpy.ops.render.render(write_still=True)
print('MP5 previews and GLB export finished.')
